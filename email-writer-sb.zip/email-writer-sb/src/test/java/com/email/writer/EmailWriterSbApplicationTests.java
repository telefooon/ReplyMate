package com.email.writer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailWriterSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
